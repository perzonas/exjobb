CREATE TRIGGER create_compartment_heap BEFORE INSERT ON heaps 
                    WHEN NEW.h_target > 0 AND 
                    (SELECT targets.t_parent_id FROM targets WHERE targets._ID = NEW.h_target LIMIT 1) <= 0 
                    BEGIN INSERT INTO heaps (h_workorder, h_target, h_date, h_finished, h_weighing) 
                    SELECT new. h_workorder, targets, ID, new.h_date, new.h_finished, new.h_weighing FROM targets 
                    WHERE new.h_target = targets.t_parent_id; END;

