CREATE TRIGGER delete_compartments 
                    AFTER DELETE ON targets
                    FOR EACH ROW BEGIN DELETE FROM targets 
                    WHERE t_parent_id = OLD._id; END;

